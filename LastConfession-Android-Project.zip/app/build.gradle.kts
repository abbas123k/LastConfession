plugins {
    id("com.android.application")
}
android {
    namespace = "com.lastconfession.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.lastconfession.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
